# Planificador Dieciochero

Tarea 1 de Sistemas Operativos: simulador de actividades representadas como un
grafo aciclico dirigido (DAG), implementado con **procesos, pipes y señales**.
No utiliza threads ni mecanismos de sincronizacion de hilos.

## 1. Compilacion

Requisitos: sistema Unix/Linux y GCC con soporte para C17.

```bash
make
```

El `Makefile` usa la compilacion solicitada en la rubrica:

```bash
gcc -Wall -Wextra -std=c17 planificador.c -o planificador -lpthread
```

Aunque la pauta incluye `-lpthread`, el codigo no crea ni sincroniza hilos.

## 2. Ejecucion

```bash
./planificador plan.txt K
```

Ejemplo con un maximo de tres procesos concurrentes:

```bash
./planificador plan.txt 3
```

Para conocer los limites detectados en el computador y el K maximo conservador:

```bash
./planificador --limites
```

`K` debe ser positivo, no puede superar las 10000 actividades exigidas y debe
caber en los limites de procesos y descriptores del equipo.

## 3. Formato de `plan.txt`

Cada linea posee exactamente cuatro campos separados por `:`:

```text
ID : nombre : tiempo_ms : dependencia1, dependencia2
```

Ejemplo:

```text
1 : prender_carbon : 500 :
2 : comprar_carne : 1200 :
3 : asar_longaniza : 800 : 1, 2
```

- El ID debe ser unico y puede contener letras, numeros, `_` o `-`.
- El nombre no puede estar vacio.
- El tiempo debe ser un entero positivo en milisegundos.
- Si el tiempo esta vacio, se asigna aleatoriamente entre 100 y 5000 ms.
- Las dependencias pueden aparecer antes o despues de su definicion.
- Se permiten lineas vacias y comentarios que comiencen con `#`.

### Validacion detallada de los campos

| Campo | Validacion aplicada | Motivo |
|---|---|---|
| `ID_Actividad` | Obligatorio, unico, maximo 47 caracteres; letras, numeros, `_` y `-` | Permite identificar cada nodo y transportarlo completo en el mensaje acotado |
| `Nombre_Actividad` | Obligatorio y no vacio | Cada actividad debe ser reconocible en la salida |
| `tiempo_ms` | Vacio o entero positivo dentro del rango de `unsigned` | Vacio genera 100-5000 ms; cero, negativos y texto se rechazan |
| `Dependencias` | Lista opcional separada por comas; IDs validos, existentes y no repetidos | Evita aristas invalidas y grados de entrada incorrectos |

La linea debe contener exactamente tres separadores `:` para formar los cuatro
campos. El programa tolera espacios alrededor de cada campo. Despues del
parseo, valida que no existan autodependencias ni ciclos. Todos los errores
indican el campo o la linea involucrada y se detectan antes de crear hijos.

## 4. Funciones implementadas

### Parseo y validacion

`read_plan_file()` lee con `getline()`, separa los cuatro campos y crea las
actividades. `build_graph()` resuelve los IDs mediante una tabla hash y crea
listas de adyacencia compactas. Esto evita comparar todos los nodos entre si y
permite trabajar con 10000 actividades.

`validate_acyclic()` aplica el algoritmo de Kahn: comienza con nodos de grado de
entrada cero y elimina sus aristas. Si no visita todos los nodos, existe un
ciclo y el archivo no representa un DAG.

### Creacion de procesos y limite K

`execute_plan()` mantiene una cola de actividades listas y un arreglo con los
hijos activos. Solo llama a `fork()` cuando:

1. todas las dependencias de la actividad terminaron exitosamente; y
2. la cantidad de hijos activos es menor que K.

Cada actividad se ejecuta en un proceso distinto. El padre espera terminaciones
mediante `waitpid(-1, ..., 0)`, que bloquea al proceso mientras no termina un
hijo. Por ello no existe un ciclo de consulta continua ni busy-waiting.

El padre es el unico que modifica el estado del DAG y la cola de listos. Los
hijos trabajan sobre copias creadas por `fork()`, de modo que no hay memoria
compartida ni race conditions sobre esas estructuras.

#### Como se averigua cuanto K soporta el computador

No existe un unico K determinado por el procesador. Un sistema puede mantener
mas procesos que nucleos porque el kernel reparte el tiempo de CPU. El comando
`--limites` consulta:

- nucleos logicos con `sysconf(_SC_NPROCESSORS_ONLN)`;
- maximo de procesos/hijos con `RLIMIT_NPROC` y `_SC_CHILD_MAX`;
- maximo de descriptores abiertos con `RLIMIT_NOFILE`;
- en Linux, cantidad actual de procesos del usuario.

El K maximo mostrado reserva margen para otros procesos y descriptores y toma
el menor limite aplicable. Para trabajo principalmente de CPU, los nucleos
logicos son un K inicial razonable; para esta simulacion, que pasa gran parte
del tiempo durmiendo, un K mayor tambien puede ser util.

### Paso de mensajes con pipes

Por cada hijo se crean dos pipes temporales:

- **Pipe de entrada:** el planificador entrega al hijo un mensaje acotado por
  cada dependencia terminada.
- **Pipe de resultado:** el hijo informa al planificador si finalizo y entrega
  un texto acotado. El planificador conserva y reenvia ese insumo cuando inicia
  las actividades dependientes.

Los mensajes tienen tamano fijo (`PipeMessage`) y las funciones `read_full()` y
`write_full()` manejan lecturas/escrituras parciales e interrupciones. Los
descriptores que no usa cada proceso se cierran inmediatamente. Al mantener
pipes solo para hijos activos, el consumo de descriptores depende de K y no de
las 10000 actividades.

### Aislamiento de errores

Si un hijo informa un fallo, termina por senal o no entrega un mensaje valido:

- esa actividad queda en estado `FAILED`;
- sus descendientes quedan en estado `BLOCKED`;
- las ramas independientes siguen ejecutandose normalmente.

Como el enunciado no define una marca de fallo dentro de `plan.txt`, se agrego
una variable de entorno solo para probar este requisito sin cambiar el formato:

```bash
PLANIFICADOR_FAIL_ID=1 ./planificador plan.txt 3
```

Esto fuerza el fallo de la actividad con ID `1`. En uso normal no se define la
variable y las actividades simuladas finalizan correctamente. Tambien se
consideran fallos reales de `fork`, pipes, salida anormal y mensajes incompletos.

### Ctrl+C / SIGINT

El manejador de SIGINT solo modifica una variable de tipo `sig_atomic_t`, que
es una operacion segura dentro de una rutina de senal. El flujo principal
detecta la marca, envia SIGTERM a todos los hijos activos, los recolecta con
`waitpid()` y termina con codigo 130. No se crean nuevas actividades despues de
la interrupcion.

### Prevencion de procesos zombies y huerfanos

- **Zombies:** todo hijo creado queda registrado. En ejecucion normal el padre
  usa `waitpid()` cuando termina; durante Ctrl+C envia SIGTERM y despues llama
  `waitpid()` para cada hijo. Incluso un hijo que falle al usar un pipe se
  conserva en la lista hasta ser recolectado.
- **Huerfanos:** en Linux, inmediatamente despues de `fork()` el hijo configura
  `prctl(PR_SET_PDEATHSIG, SIGTERM)`. Si el planificador desaparece de forma
  inesperada, el kernel envia SIGTERM al hijo. Ademas se comprueba `getppid()`
  para cubrir la pequena ventana entre `fork()` y `prctl()`.
- Los hijos cierran descriptores heredados de otros hijos, y padre e hijo
  cierran siempre los extremos de pipe que no utilizan.

## 5. Decisiones de diseno

- **Un proceso por actividad:** satisface directamente el objetivo de practicar
  procesos y mantiene aislados los fallos.
- **Planificador central:** una sola entidad cambia estados y dependencias. Esto
  simplifica el control de K y elimina carreras sobre el DAG.
- **Pipes creados bajo demanda:** evita abrir miles de descriptores antes de
  comenzar y permite la prueba de 10000 nodos.
- **Tabla hash y adyacencia compacta:** parseo y recorrido cercanos a
  `O(V + E)`, donde V son actividades y E dependencias.
- **No se usa memoria compartida:** toda comunicacion entre padre e hijos ocurre
  mediante pipes y el estado central queda en el padre.

## 6. Pruebas

Para ejecutar todas las pruebas:

```bash
make test
```

La bateria comprueba:

1. ejecucion normal y respeto de dependencias;
2. rechazo de un ciclo;
3. fallo de una rama mientras otra termina;
4. cancelacion mediante SIGINT;
5. plan en cadena con 10000 actividades.

Tambien se recomienda probar manualmente distintos valores de K y observar que
nunca aparecen mas de K procesos de actividad activos.

## 7. Relacion con la rubrica

| Criterio | Evidencia en la solucion |
|---|---|
| 1.1 Parseo | Cuatro campos, validaciones, duracion aleatoria y errores claros |
| 1.2 DAG | Tabla de IDs, listas de adyacencia y deteccion de ciclos |
| 1.3 Procesos | Un `fork()` real por cada actividad ejecutada |
| 2.1 Concurrencia | Cola de listos, maximo K, `waitpid()` bloqueante y estado solo en el padre |
| 2.2 Pipes | Mensajes acotados de dependencias y resultados por pipes |
| 2.3 Errores | Estados `FAILED/BLOCKED` y continuacion de ramas independientes |
| 2.4 Estres | Estructuras dinamicas, pocos descriptores simultaneos y prueba de 10000 nodos |

## 8. Estructura

```text
planificador_dieciochero/
|- planificador.c
|- Makefile
|- plan.txt
|- README.md
`- tests/
   |- plan_ramas.txt
   |- plan_ciclo.txt
   `- run_tests.sh
```

## 9. Autoria

Antes de entregar, agregar aqui los nombres de los integrantes y explicar en
forma honesta la contribucion de cada persona. Ambos integrantes deben realizar
commits propios dentro del plazo establecido.
