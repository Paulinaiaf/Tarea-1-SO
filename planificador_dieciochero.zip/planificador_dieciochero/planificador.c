#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/resource.h>
#ifdef __linux__
#include <sys/prctl.h>
#endif
#include <time.h>
#include <unistd.h>

#define MESSAGE_TEXT_SIZE 128

typedef enum {
    PENDING,
    READY,
    RUNNING,
    SUCCESS,
    FAILED,
    BLOCKED
} State;

typedef struct {
    char *id;
    char *name;
    unsigned duration_ms;
    char **dependency_ids;
    size_t dependency_count;
    size_t *dependencies;
    size_t remaining_dependencies;
    State state;
    pid_t pid;
    int result_fd;
    int exit_status;
    char result_message[MESSAGE_TEXT_SIZE];
} Activity;

typedef struct {
    Activity *activities;
    size_t count;
    size_t capacity;
    size_t *edge_offsets;
    size_t *edges;
    size_t edge_count;
} Plan;

typedef struct {
    size_t activity_index;
    pid_t pid;
    int result_fd;
} RunningChild;

typedef struct {
    char source_id[48];
    int success;
    char text[MESSAGE_TEXT_SIZE];
} PipeMessage;

typedef struct {
    const char **keys;
    size_t *values;
    size_t capacity;
} IdMap;

static volatile sig_atomic_t interrupted = 0;

static void handle_sigint(int signal_number) {
    (void)signal_number;
    interrupted = 1;
}

static void die_usage(const char *program) {
    fprintf(stderr, "Uso: %s plan.txt K\n", program);
    fprintf(stderr, "     %s --limites\n", program);
}

static void *xmalloc(size_t size) {
    if (size == 0) {
        size = 1;
    }
    void *pointer = malloc(size);
    if (pointer == NULL) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }
    return pointer;
}

static void *xcalloc(size_t count, size_t size) {
    if (count == 0 || size == 0) {
        count = 1;
        size = 1;
    }
    void *pointer = calloc(count, size);
    if (pointer == NULL) {
        perror("calloc");
        exit(EXIT_FAILURE);
    }
    return pointer;
}

static void *xrealloc(void *pointer, size_t size) {
    void *new_pointer = realloc(pointer, size);
    if (new_pointer == NULL) {
        perror("realloc");
        exit(EXIT_FAILURE);
    }
    return new_pointer;
}

static char *xstrdup(const char *text) {
    char *copy = strdup(text);
    if (copy == NULL) {
        perror("strdup");
        exit(EXIT_FAILURE);
    }
    return copy;
}

static char *trim(char *text) {
    while (isspace((unsigned char)*text)) {
        text++;
    }
    char *end = text + strlen(text);
    while (end > text && isspace((unsigned char)end[-1])) {
        end--;
    }
    *end = '\0';
    return text;
}

static uint64_t hash_id(const char *text) {
    uint64_t hash = UINT64_C(1469598103934665603);
    while (*text != '\0') {
        hash ^= (unsigned char)*text++;
        hash *= UINT64_C(1099511628211);
    }
    return hash;
}

static size_t next_power_of_two(size_t value) {
    size_t result = 1;
    while (result < value) {
        result *= 2;
    }
    return result;
}

static void id_map_init(IdMap *map, size_t expected) {
    map->capacity = next_power_of_two(expected * 2 + 1);
    map->keys = xcalloc(map->capacity, sizeof(*map->keys));
    map->values = xmalloc(map->capacity * sizeof(*map->values));
}

static bool id_map_insert(IdMap *map, const char *key, size_t value) {
    size_t slot = (size_t)hash_id(key) & (map->capacity - 1);
    while (map->keys[slot] != NULL) {
        if (strcmp(map->keys[slot], key) == 0) {
            return false;
        }
        slot = (slot + 1) & (map->capacity - 1);
    }
    map->keys[slot] = key;
    map->values[slot] = value;
    return true;
}

static bool id_map_find(const IdMap *map, const char *key, size_t *value) {
    size_t slot = (size_t)hash_id(key) & (map->capacity - 1);
    while (map->keys[slot] != NULL) {
        if (strcmp(map->keys[slot], key) == 0) {
            *value = map->values[slot];
            return true;
        }
        slot = (slot + 1) & (map->capacity - 1);
    }
    return false;
}

static void id_map_destroy(IdMap *map) {
    free(map->keys);
    free(map->values);
}

static bool valid_id(const char *id) {
    if (*id == '\0' || strlen(id) >= sizeof(((PipeMessage *)0)->source_id)) {
        return false;
    }
    for (const unsigned char *cursor = (const unsigned char *)id;
         *cursor != '\0'; cursor++) {
        if (!isalnum(*cursor) && *cursor != '_' && *cursor != '-') {
            return false;
        }
    }
    return true;
}

static bool parse_duration(const char *text, unsigned *duration) {
    if (*text == '\0') {
        *duration = 100U + (unsigned)(rand() % 4901);
        return true;
    }
    errno = 0;
    char *end = NULL;
    unsigned long value = strtoul(text, &end, 10);
    if (errno != 0 || *end != '\0' || value == 0 || value > UINT32_MAX) {
        return false;
    }
    *duration = (unsigned)value;
    return true;
}

static bool split_four_fields(char *line, char **fields) {
    char *cursor = line;
    for (size_t index = 0; index < 3; index++) {
        char *separator = strchr(cursor, ':');
        if (separator == NULL) {
            return false;
        }
        *separator = '\0';
        fields[index] = trim(cursor);
        cursor = separator + 1;
    }
    if (strchr(cursor, ':') != NULL) {
        return false;
    }
    fields[3] = trim(cursor);
    return true;
}

static bool parse_dependencies(Activity *activity, char *field,
                               size_t line_number) {
    if (*field == '\0') {
        return true;
    }
    char *save_pointer = NULL;
    for (char *token = strtok_r(field, ",", &save_pointer); token != NULL;
         token = strtok_r(NULL, ",", &save_pointer)) {
        char *dependency = trim(token);
        if (!valid_id(dependency)) {
            fprintf(stderr, "Error en linea %zu: dependencia invalida '%s'.\n",
                    line_number, dependency);
            return false;
        }
        activity->dependency_ids = xrealloc(
            activity->dependency_ids,
            (activity->dependency_count + 1) * sizeof(char *));
        activity->dependency_ids[activity->dependency_count++] =
            xstrdup(dependency);
    }
    return true;
}

static void free_plan(Plan *plan) {
    for (size_t index = 0; index < plan->count; index++) {
        Activity *activity = &plan->activities[index];
        free(activity->id);
        free(activity->name);
        for (size_t dep = 0; dep < activity->dependency_count; dep++) {
            free(activity->dependency_ids[dep]);
        }
        free(activity->dependency_ids);
        free(activity->dependencies);
    }
    free(plan->activities);
    free(plan->edge_offsets);
    free(plan->edges);
}

static bool read_plan_file(const char *path, Plan *plan) {
    FILE *file = fopen(path, "r");
    if (file == NULL) {
        perror(path);
        return false;
    }

    char *line = NULL;
    size_t line_capacity = 0;
    ssize_t length;
    size_t line_number = 0;
    bool valid = true;

    while ((length = getline(&line, &line_capacity, file)) != -1) {
        line_number++;
        while (length > 0 && (line[length - 1] == '\n' ||
                              line[length - 1] == '\r')) {
            line[--length] = '\0';
        }
        char *content = trim(line);
        if (*content == '\0' || *content == '#') {
            continue;
        }

        char *fields[4];
        if (!split_four_fields(content, fields)) {
            fprintf(stderr,
                    "Error en linea %zu: se esperaban exactamente 4 campos.\n",
                    line_number);
            valid = false;
            break;
        }
        if (!valid_id(fields[0]) || *fields[1] == '\0') {
            fprintf(stderr, "Error en linea %zu: ID o nombre invalido.\n",
                    line_number);
            valid = false;
            break;
        }

        if (plan->count == plan->capacity) {
            plan->capacity = plan->capacity == 0 ? 16 : plan->capacity * 2;
            plan->activities = xrealloc(
                plan->activities, plan->capacity * sizeof(Activity));
        }
        Activity *activity = &plan->activities[plan->count];
        memset(activity, 0, sizeof(*activity));
        activity->id = xstrdup(fields[0]);
        activity->name = xstrdup(fields[1]);
        activity->result_fd = -1;
        activity->state = PENDING;

        if (!parse_duration(fields[2], &activity->duration_ms) ||
            !parse_dependencies(activity, fields[3], line_number)) {
            if (*fields[2] != '\0' && activity->duration_ms == 0) {
                fprintf(stderr, "Error en linea %zu: tiempo invalido.\n",
                        line_number);
            }
            plan->count++;
            valid = false;
            break;
        }
        plan->count++;
    }

    if (ferror(file)) {
        perror("getline");
        valid = false;
    }
    free(line);
    fclose(file);

    if (valid && plan->count == 0) {
        fprintf(stderr, "Error: el plan no contiene actividades.\n");
        valid = false;
    }
    return valid;
}

static bool build_graph(Plan *plan) {
    IdMap map;
    id_map_init(&map, plan->count);
    bool valid = true;

    for (size_t index = 0; index < plan->count; index++) {
        if (!id_map_insert(&map, plan->activities[index].id, index)) {
            fprintf(stderr, "Error: ID duplicado '%s'.\n",
                    plan->activities[index].id);
            valid = false;
            break;
        }
    }

    size_t *outgoing_counts = xcalloc(plan->count, sizeof(*outgoing_counts));
    if (valid) {
        for (size_t index = 0; index < plan->count && valid; index++) {
            Activity *activity = &plan->activities[index];
            activity->dependencies = xmalloc(
                activity->dependency_count * sizeof(size_t));
            activity->remaining_dependencies = activity->dependency_count;
            for (size_t dep = 0; dep < activity->dependency_count; dep++) {
                size_t source;
                if (!id_map_find(&map, activity->dependency_ids[dep], &source)) {
                    fprintf(stderr,
                            "Error: '%s' depende de ID inexistente '%s'.\n",
                            activity->id, activity->dependency_ids[dep]);
                    valid = false;
                    break;
                }
                if (source == index) {
                    fprintf(stderr, "Error: '%s' depende de si misma.\n",
                            activity->id);
                    valid = false;
                    break;
                }
                for (size_t prior = 0; prior < dep; prior++) {
                    if (activity->dependencies[prior] == source) {
                        fprintf(stderr,
                                "Error: dependencia repetida '%s' en '%s'.\n",
                                activity->dependency_ids[dep], activity->id);
                        valid = false;
                        break;
                    }
                }
                if (!valid) {
                    break;
                }
                activity->dependencies[dep] = source;
                outgoing_counts[source]++;
                plan->edge_count++;
            }
        }
    }

    if (valid) {
        plan->edge_offsets = xcalloc(plan->count + 1,
                                     sizeof(*plan->edge_offsets));
        for (size_t index = 0; index < plan->count; index++) {
            plan->edge_offsets[index + 1] =
                plan->edge_offsets[index] + outgoing_counts[index];
        }
        plan->edges = xmalloc(plan->edge_count * sizeof(*plan->edges));
        size_t *positions = xmalloc(plan->count * sizeof(*positions));
        memcpy(positions, plan->edge_offsets,
               plan->count * sizeof(*positions));
        for (size_t target = 0; target < plan->count; target++) {
            Activity *activity = &plan->activities[target];
            for (size_t dep = 0; dep < activity->dependency_count; dep++) {
                size_t source = activity->dependencies[dep];
                plan->edges[positions[source]++] = target;
            }
        }
        free(positions);
    }

    free(outgoing_counts);
    id_map_destroy(&map);
    return valid;
}

static bool validate_acyclic(const Plan *plan) {
    size_t *indegree = xmalloc(plan->count * sizeof(*indegree));
    size_t *queue = xmalloc(plan->count * sizeof(*queue));
    size_t head = 0;
    size_t tail = 0;

    for (size_t index = 0; index < plan->count; index++) {
        indegree[index] = plan->activities[index].dependency_count;
        if (indegree[index] == 0) {
            queue[tail++] = index;
        }
    }
    size_t visited = 0;
    while (head < tail) {
        size_t source = queue[head++];
        visited++;
        for (size_t edge = plan->edge_offsets[source];
             edge < plan->edge_offsets[source + 1]; edge++) {
            size_t target = plan->edges[edge];
            if (--indegree[target] == 0) {
                queue[tail++] = target;
            }
        }
    }
    free(indegree);
    free(queue);
    if (visited != plan->count) {
        fprintf(stderr, "Error: el plan contiene al menos un ciclo; no es un DAG.\n");
        return false;
    }
    return true;
}

static ssize_t write_full(int fd, const void *buffer, size_t size) {
    const char *cursor = buffer;
    size_t written = 0;
    while (written < size) {
        ssize_t result = write(fd, cursor + written, size - written);
        if (result < 0 && errno == EINTR) {
            continue;
        }
        if (result <= 0) {
            return -1;
        }
        written += (size_t)result;
    }
    return (ssize_t)written;
}

static ssize_t read_full(int fd, void *buffer, size_t size) {
    char *cursor = buffer;
    size_t received = 0;
    while (received < size) {
        ssize_t result = read(fd, cursor + received, size - received);
        if (result < 0 && errno == EINTR) {
            continue;
        }
        if (result <= 0) {
            return result == 0 && received == 0 ? 0 : -1;
        }
        received += (size_t)result;
    }
    return (ssize_t)received;
}

static unsigned long finite_limit(rlim_t value) {
    if (value == RLIM_INFINITY || value > (rlim_t)100000000UL) {
        return 100000000UL;
    }
    return (unsigned long)value;
}

static size_t current_user_processes(void) {
#ifdef __linux__
    DIR *directory = opendir("/proc");
    if (directory == NULL) {
        return 0;
    }
    uid_t own_uid = getuid();
    size_t count = 0;
    struct dirent *entry;
    while ((entry = readdir(directory)) != NULL) {
        if (!isdigit((unsigned char)entry->d_name[0])) {
            continue;
        }
        char path[300];
        snprintf(path, sizeof(path), "/proc/%s/status", entry->d_name);
        FILE *status = fopen(path, "r");
        if (status == NULL) {
            continue;
        }
        char line[256];
        while (fgets(line, sizeof(line), status) != NULL) {
            unsigned long real_uid;
            if (sscanf(line, "Uid:\t%lu", &real_uid) == 1) {
                if ((uid_t)real_uid == own_uid) {
                    count++;
                }
                break;
            }
        }
        fclose(status);
    }
    closedir(directory);
    return count;
#else
    return 0;
#endif
}

static size_t calculate_safe_k(bool show_details) {
    struct rlimit fd_limit;
    struct rlimit process_limit;
    bool have_fd = getrlimit(RLIMIT_NOFILE, &fd_limit) == 0;
    bool have_process = getrlimit(RLIMIT_NPROC, &process_limit) == 0;
    long online_cpus = sysconf(_SC_NPROCESSORS_ONLN);
    long child_max = sysconf(_SC_CHILD_MAX);
    size_t used_processes = current_user_processes();

    size_t by_fds = 10000;
    if (have_fd) {
        unsigned long soft_fds = finite_limit(fd_limit.rlim_cur);
        by_fds = soft_fds > 32 ? (size_t)(soft_fds - 32) : 1;
    }
    size_t by_processes = 10000;
    if (have_process && process_limit.rlim_cur != RLIM_INFINITY) {
        unsigned long soft_processes = finite_limit(process_limit.rlim_cur);
        by_processes = soft_processes > used_processes + 16
                           ? (size_t)(soft_processes - used_processes - 16)
                           : 1;
    }
    if (child_max > 0 && (size_t)child_max < by_processes) {
        by_processes = (size_t)child_max;
    }

    size_t safe = by_fds < by_processes ? by_fds : by_processes;
    if (safe > 10000) {
        safe = 10000;
    }
    if (safe == 0) {
        safe = 1;
    }

    if (show_details) {
        printf("=== LIMITES DEL EQUIPO ===\n");
        printf("Nucleos logicos disponibles: %ld\n", online_cpus);
        if (have_fd) {
            printf("Limite blando de descriptores por proceso: %lu\n",
                   finite_limit(fd_limit.rlim_cur));
        } else {
            printf("Limite de descriptores: no disponible\n");
        }
        if (have_process) {
            if (process_limit.rlim_cur == RLIM_INFINITY) {
                printf("Limite de procesos por usuario: sin limite RLIMIT_NPROC\n");
            } else {
                printf("Limite blando de procesos por usuario: %lu\n",
                       finite_limit(process_limit.rlim_cur));
            }
        }
        if (used_processes > 0) {
            printf("Procesos actuales del usuario: %zu\n", used_processes);
        }
        printf("K maximo conservador para este programa: %zu\n", safe);
        printf("K recomendado para paralelismo de CPU: %ld (nucleos logicos)\n",
               online_cpus > 0 ? online_cpus : 1);
        printf("Nota: se pueden crear mas procesos que nucleos; solo comparten CPU.\n");
    }
    return safe;
}

static void sleep_milliseconds(unsigned milliseconds) {
    struct timespec remaining = {
        .tv_sec = (time_t)(milliseconds / 1000U),
        .tv_nsec = (long)(milliseconds % 1000U) * 1000000L
    };
    while (nanosleep(&remaining, &remaining) == -1 && errno == EINTR) {
    }
}

static void child_work(const Activity *activity, int input_fd, int output_fd) {
    struct sigaction default_action;
    memset(&default_action, 0, sizeof(default_action));
    default_action.sa_handler = SIG_DFL;
    sigemptyset(&default_action.sa_mask);
    sigaction(SIGINT, &default_action, NULL);
    sigaction(SIGTERM, &default_action, NULL);

    PipeMessage input;
    for (size_t dep = 0; dep < activity->dependency_count; dep++) {
        if (read_full(input_fd, &input, sizeof(input)) !=
            (ssize_t)sizeof(input)) {
            _exit(2);
        }
        printf("[PID %ld] %s recibio insumo de %s: %s\n",
               (long)getpid(), activity->id, input.source_id, input.text);
    }
    close(input_fd);

    printf("[PID %ld] INICIO %s (%s), duracion=%u ms\n",
           (long)getpid(), activity->id, activity->name,
           activity->duration_ms);
    fflush(stdout);
    sleep_milliseconds(activity->duration_ms);

    PipeMessage result;
    memset(&result, 0, sizeof(result));
    snprintf(result.source_id, sizeof(result.source_id), "%s", activity->id);
    const char *forced_failure = getenv("PLANIFICADOR_FAIL_ID");
    result.success = forced_failure == NULL ||
                     strcmp(forced_failure, activity->id) != 0;
    snprintf(result.text, sizeof(result.text), "%s termino %s",
             activity->name, result.success ? "correctamente" : "con error");

    if (write_full(output_fd, &result, sizeof(result)) == -1) {
        close(output_fd);
        _exit(3);
    }
    close(output_fd);
    printf("[PID %ld] FIN %s: %s\n", (long)getpid(), activity->id,
           result.success ? "OK" : "FALLO");
    fflush(stdout);
    _exit(result.success ? 0 : 1);
}

static bool start_activity(Plan *plan, size_t index,
                           RunningChild *running_slot,
                           const RunningChild *active_children,
                           size_t active_count) {
    int input_pipe[2];
    int result_pipe[2];
    if (pipe(input_pipe) == -1) {
        perror("pipe entrada");
        return false;
    }
    if (pipe(result_pipe) == -1) {
        perror("pipe resultado");
        close(input_pipe[0]);
        close(input_pipe[1]);
        return false;
    }

    Activity *activity = &plan->activities[index];
    pid_t parent_pid = getpid();
    /* Evita que buffers previos de stdio se impriman nuevamente en el hijo. */
    fflush(NULL);
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        close(input_pipe[0]);
        close(input_pipe[1]);
        close(result_pipe[0]);
        close(result_pipe[1]);
        return false;
    }
    if (pid == 0) {
#ifdef __linux__
        /* Si el planificador muere inesperadamente, el kernel termina al hijo. */
        if (prctl(PR_SET_PDEATHSIG, SIGTERM) == -1 ||
            getppid() != parent_pid) {
            _exit(4);
        }
#endif
        for (size_t child = 0; child < active_count; child++) {
            close(active_children[child].result_fd);
        }
        close(input_pipe[1]);
        close(result_pipe[0]);
        child_work(activity, input_pipe[0], result_pipe[1]);
    }

    close(input_pipe[0]);
    close(result_pipe[1]);
    activity->pid = pid;
    activity->state = RUNNING;
    activity->result_fd = result_pipe[0];
    running_slot->activity_index = index;
    running_slot->pid = pid;
    running_slot->result_fd = result_pipe[0];

    bool messages_ok = true;
    for (size_t dep = 0; dep < activity->dependency_count; dep++) {
        Activity *source = &plan->activities[activity->dependencies[dep]];
        PipeMessage message;
        memset(&message, 0, sizeof(message));
        snprintf(message.source_id, sizeof(message.source_id), "%s", source->id);
        message.success = 1;
        snprintf(message.text, sizeof(message.text), "%s",
                 source->result_message);
        if (write_full(input_pipe[1], &message, sizeof(message)) == -1) {
            perror("write pipe entrada");
            messages_ok = false;
            break;
        }
    }
    close(input_pipe[1]);
    if (!messages_ok) {
        kill(pid, SIGTERM);
    }
    /* Aunque falle el envio, el hijo queda registrado para ser recolectado. */
    return true;
}

static size_t find_running_child(const RunningChild *children,
                                 size_t running_count, pid_t pid) {
    for (size_t index = 0; index < running_count; index++) {
        if (children[index].pid == pid) {
            return index;
        }
    }
    return running_count;
}

static size_t block_descendants(Plan *plan, size_t failed_index) {
    size_t *queue = xmalloc(plan->count * sizeof(*queue));
    size_t head = 0;
    size_t tail = 0;
    size_t blocked_count = 0;
    queue[tail++] = failed_index;

    while (head < tail) {
        size_t source = queue[head++];
        for (size_t edge = plan->edge_offsets[source];
             edge < plan->edge_offsets[source + 1]; edge++) {
            size_t target = plan->edges[edge];
            Activity *activity = &plan->activities[target];
            if (activity->state == PENDING || activity->state == READY) {
                activity->state = BLOCKED;
                blocked_count++;
                printf("[BLOQUEADA] %s depende de una rama fallida.\n",
                       activity->id);
                queue[tail++] = target;
            }
        }
    }
    free(queue);
    return blocked_count;
}

static void terminate_running(RunningChild *children, size_t running_count) {
    for (size_t index = 0; index < running_count; index++) {
        kill(children[index].pid, SIGTERM);
    }
    for (size_t index = 0; index < running_count; index++) {
        while (waitpid(children[index].pid, NULL, 0) == -1 && errno == EINTR) {
        }
        close(children[index].result_fd);
    }
}

static int execute_plan(Plan *plan, size_t concurrency_limit) {
    size_t *ready_queue = xmalloc(plan->count * sizeof(*ready_queue));
    size_t ready_head = 0;
    size_t ready_tail = 0;
    RunningChild *children = xmalloc(concurrency_limit * sizeof(*children));
    size_t running_count = 0;
    size_t finished_count = 0;
    size_t success_count = 0;
    size_t failed_count = 0;
    size_t blocked_count = 0;

    for (size_t index = 0; index < plan->count; index++) {
        if (plan->activities[index].remaining_dependencies == 0) {
            plan->activities[index].state = READY;
            ready_queue[ready_tail++] = index;
        }
    }

    while (finished_count < plan->count && !interrupted) {
        while (running_count < concurrency_limit && ready_head < ready_tail &&
               !interrupted) {
            size_t index = ready_queue[ready_head++];
            if (plan->activities[index].state != READY) {
                continue;
            }
            if (!start_activity(plan, index, &children[running_count],
                                children, running_count)) {
                plan->activities[index].state = FAILED;
                failed_count++;
                finished_count++;
                size_t newly_blocked = block_descendants(plan, index);
                blocked_count += newly_blocked;
                finished_count += newly_blocked;
                continue;
            }
            running_count++;
        }

        if (running_count == 0) {
            break;
        }

        int status = 0;
        pid_t finished_pid;
        do {
            finished_pid = waitpid(-1, &status, 0);
        } while (finished_pid == -1 && errno == EINTR && !interrupted);

        if (interrupted) {
            break;
        }
        if (finished_pid == -1) {
            perror("waitpid");
            interrupted = 1;
            break;
        }

        size_t child_slot = find_running_child(children, running_count,
                                                finished_pid);
        if (child_slot == running_count) {
            fprintf(stderr, "Error interno: PID hijo desconocido.\n");
            interrupted = 1;
            break;
        }
        size_t activity_index = children[child_slot].activity_index;
        Activity *activity = &plan->activities[activity_index];
        PipeMessage result;
        memset(&result, 0, sizeof(result));
        ssize_t bytes = read_full(children[child_slot].result_fd, &result,
                                  sizeof(result));
        close(children[child_slot].result_fd);
        children[child_slot] = children[running_count - 1];
        running_count--;
        finished_count++;

        bool succeeded = WIFEXITED(status) && WEXITSTATUS(status) == 0 &&
                         bytes == (ssize_t)sizeof(result) && result.success;
        if (succeeded) {
            activity->state = SUCCESS;
            activity->exit_status = 0;
            snprintf(activity->result_message,
                     sizeof(activity->result_message), "%s", result.text);
            success_count++;
            for (size_t edge = plan->edge_offsets[activity_index];
                 edge < plan->edge_offsets[activity_index + 1]; edge++) {
                size_t target = plan->edges[edge];
                Activity *dependent = &plan->activities[target];
                if (dependent->state == PENDING &&
                    --dependent->remaining_dependencies == 0) {
                    dependent->state = READY;
                    ready_queue[ready_tail++] = target;
                }
            }
        } else {
            activity->state = FAILED;
            activity->exit_status = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
            failed_count++;
            fprintf(stderr, "[FALLO] Actividad %s (PID %ld).\n",
                    activity->id, (long)finished_pid);
            size_t newly_blocked = block_descendants(plan, activity_index);
            blocked_count += newly_blocked;
            finished_count += newly_blocked;
        }
    }

    if (interrupted) {
        fprintf(stderr, "\n[SIGINT] Inspeccion de la Seremi: abortando actividades.\n");
        terminate_running(children, running_count);
        free(ready_queue);
        free(children);
        return 130;
    }

    printf("\n=== RESUMEN ===\n");
    printf("Total: %zu | Exitosas: %zu | Fallidas: %zu | Bloqueadas: %zu\n",
           plan->count, success_count, failed_count, blocked_count);
    free(ready_queue);
    free(children);
    return failed_count == 0 ? EXIT_SUCCESS : EXIT_FAILURE;
}

int main(int argc, char **argv) {
    if (argc == 2 && strcmp(argv[1], "--limites") == 0) {
        calculate_safe_k(true);
        return EXIT_SUCCESS;
    }
    if (argc != 3) {
        die_usage(argv[0]);
        return EXIT_FAILURE;
    }
    errno = 0;
    char *end = NULL;
    unsigned long parsed_k = strtoul(argv[2], &end, 10);
    size_t safe_k = calculate_safe_k(false);
    if (errno != 0 || *argv[2] == '\0' || *end != '\0' || parsed_k == 0 ||
        parsed_k > safe_k) {
        fprintf(stderr, "Error: K debe ser un entero entre 1 y %zu en este equipo.\n",
                safe_k);
        fprintf(stderr, "Ejecute '%s --limites' para ver el calculo.\n", argv[0]);
        return EXIT_FAILURE;
    }

    struct sigaction action;
    memset(&action, 0, sizeof(action));
    action.sa_handler = handle_sigint;
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGINT, &action, NULL) == -1) {
        perror("sigaction");
        return EXIT_FAILURE;
    }
    signal(SIGPIPE, SIG_IGN);
    srand((unsigned)(time(NULL) ^ getpid()));

    Plan plan;
    memset(&plan, 0, sizeof(plan));
    if (!read_plan_file(argv[1], &plan) || !build_graph(&plan) ||
        !validate_acyclic(&plan)) {
        free_plan(&plan);
        return EXIT_FAILURE;
    }

    printf("Plan valido: %zu actividades, %zu dependencias, K=%lu.\n",
           plan.count, plan.edge_count, parsed_k);
    int result = execute_plan(&plan, (size_t)parsed_k);
    free_plan(&plan);
    return result;
}
