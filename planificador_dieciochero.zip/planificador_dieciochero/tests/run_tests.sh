#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PROGRAM="$ROOT/planificador"
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT

passed=0
failed=0

check() {
    local name="$1"
    shift
    if "$@"; then
        echo "[OK] $name"
        passed=$((passed + 1))
    else
        echo "[FALLO] $name"
        failed=$((failed + 1))
    fi
}

normal_plan() {
    "$PROGRAM" "$ROOT/plan.txt" 3 >"$TEMP_DIR/normal.log" 2>&1 &&
        grep -q "Exitosas: 6" "$TEMP_DIR/normal.log"
}

reject_cycle() {
    ! "$PROGRAM" "$ROOT/tests/plan_ciclo.txt" 2 >"$TEMP_DIR/cycle.log" 2>&1 &&
        grep -q "ciclo" "$TEMP_DIR/cycle.log"
}

isolate_failure() {
    ! PLANIFICADOR_FAIL_ID=A "$PROGRAM" \
        "$ROOT/tests/plan_ramas.txt" 2 >"$TEMP_DIR/failure.log" 2>&1 &&
        grep -q "Exitosas: 3" "$TEMP_DIR/failure.log" &&
        grep -q "Fallidas: 1" "$TEMP_DIR/failure.log" &&
        grep -q "Bloqueadas: 2" "$TEMP_DIR/failure.log"
}

validate_fields() {
    printf 'A : tarea : texto :\n' >"$TEMP_DIR/bad_time.txt"
    printf 'A : tarea : 1 :\nA : repetida : 1 :\n' \
        >"$TEMP_DIR/duplicate.txt"
    printf 'A : tarea : 1 : NO_EXISTE\n' >"$TEMP_DIR/missing_dep.txt"
    ! "$PROGRAM" "$TEMP_DIR/bad_time.txt" 2 >/dev/null 2>&1 &&
        ! "$PROGRAM" "$TEMP_DIR/duplicate.txt" 2 >/dev/null 2>&1 &&
        ! "$PROGRAM" "$TEMP_DIR/missing_dep.txt" 2 >/dev/null 2>&1
}

respect_k() {
    for i in 1 2 3 4 5 6; do
        printf '%s : tarea_%s : 50 :\n' "$i" "$i"
    done >"$TEMP_DIR/concurrency.txt"
    "$PROGRAM" "$TEMP_DIR/concurrency.txt" 2 >"$TEMP_DIR/concurrency.log" 2>&1 ||
        return 1
    awk '
        / INICIO / { active++; if (active > maximum) maximum = active }
        / FIN / { active-- }
        END { exit !(maximum == 2 && active == 0) }
    ' "$TEMP_DIR/concurrency.log"
}

stress_test() {
    awk 'BEGIN {
        for (i = 1; i <= 10000; i++) {
            if (i == 1) printf "%d : tarea_%d : 1 :\n", i, i;
            else printf "%d : tarea_%d : 1 : %d\n", i, i, i - 1;
        }
    }' >"$TEMP_DIR/stress.txt"
    "$PROGRAM" "$TEMP_DIR/stress.txt" 32 >"$TEMP_DIR/stress.log" 2>&1 &&
        grep -q "Exitosas: 10000" "$TEMP_DIR/stress.log"
}

sigint_test() {
    printf 'A : larga_1 : 5000 :\nB : larga_2 : 5000 :\n' \
        >"$TEMP_DIR/sigint.txt"
    "$PROGRAM" "$TEMP_DIR/sigint.txt" 2 >"$TEMP_DIR/sigint.log" 2>&1 &
    local scheduler_pid=$!
    sleep 0.2
    kill -INT "$scheduler_pid"
    wait "$scheduler_pid"
    local status=$?
    [[ $status -eq 130 ]] && grep -q "SIGINT" "$TEMP_DIR/sigint.log"
}

check "plan valido y dependencias" normal_plan
check "deteccion de ciclos" reject_cycle
check "aislamiento de rama fallida" isolate_failure
check "validacion de campos incorrectos" validate_fields
check "limite de concurrencia K=2" respect_k
check "SIGINT termina el plan" sigint_test
check "carga de 10000 actividades" stress_test

echo "Pruebas superadas: $passed | fallidas: $failed"
[[ $failed -eq 0 ]]
